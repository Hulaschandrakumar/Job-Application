from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User, auth
import jobSite.models as models
import json
# Create your views here.


def Remove(duplicate):
    final_list = []
    for num in duplicate:
        if num not in final_list:
            final_list.append(num)
    return final_list

def job_details(requests):
    id = requests.GET["jobid"]
    job = models.Job.objects.get(id=id)
    applicants = job.applications.split(",")

    userlist = []
    for ids in applicants:
        if id != 0:
            user = models.Profile.objects.get(id=id)
            userlist.append(user)
    lists = {"lists": userlist}
    return render(requests, "job-details.html", lists)


def jobs(requests):
    joblist = models.Job.objects.all()
    data = {"job": joblist}
    return render(requests, "jobs.html", data)


def register(requests):
    if requests.method == "POST":
        querydict = json.loads(requests.body)
        email = querydict["email"]
        password = querydict["password"]
        if email != "" and password != "":
            token = tokenGenerator()
            print(email)
            print(password)
            user = User.objects.create_user(
                username=email, password=password, email=token)
            user.save()
            inst = models.Profile.objects.create(token=token, username=email)
        return HttpResponse('{"status":"working", "logintoken": "'+token+'"}')


def login(requests):
    if requests.method == "POST":
        querydict = json.loads(requests.body)
        email = querydict["email"]
        password = querydict["password"]
        print(email)
        print(password)
        user = auth.authenticate(username=email, password=password)
        if user is not None:
            print(user.email)
            auth.login(requests, user)
            return HttpResponse('{"status":"working", "logintoken": "'+user.email+'"}')
        else:
            return HttpResponse('{"status":"working", "logintoken": "0"}')


def tokenGenerator():
    import random
    import string
    return ''.join(random.choices(string.ascii_uppercase+string.digits, k=10))


def joblist(requests):
    if requests.method == "POST":
        querydict = json.loads(requests.body)
        print(querydict)
        n = int(querydict["offset"])
        searchs = querydict["search"]
        print("Search jobs")
        sets = models.Job.objects.filter(tags__contains=searchs)
        print(len(sets))
        if n > len(sets)-3:
            n = len(sets)-3
        if n < 0:
            n = 0
        lists = []
        userid = getUserIdFromToken(querydict["token"])
        for i in range(n, n+3):
            try:
                objects = sets[i]
                applicants = objects.applications.split(",")
                if search(applicants, userid):
                    applied = True
                else:
                    applied = False
                print(applicants)
                job = {"id": objects.id, "recruiter": objects.recruiter, "role": objects.post, "salary": "INR   " +
                       str(objects.salary), "location": objects.location, "desc": objects.description, "applied": applied}
                lists.append(job)
            except:
                break
        return HttpResponse(json.dumps({"offset": n, "joblist": lists}))


def popularlist(requests):
    return HttpResponse('[{"title":"Part time"},{"title":"Work from Home"},{"title":"Writing"},{"title":"Entry level jobs"},{"title":"Internships"},{"title":"Full time"},{"title":"Online"},{"title":"India"}]')


def apply(requests):
    if requests.method == "POST":
        querydict = json.loads(requests.body)
        print(querydict)
        userid = getUserIdFromToken(querydict["token"])
        jobid = int(querydict["jobid"])
        JobObj = models.Job.objects.get(id=jobid)
        JobObj.applications = str(JobObj.applications) + ','+str(userid)
        JobObj.save()
        return HttpResponse(json.dumps({"status": "applied"}))


def getUserIdFromToken(token):
    users = models.Profile.objects.get(token=token)
    return users.id


def search(list, n):

    for i in range(len(list)):
        if list[i] == str(n):
            return True
    return False


def profile(requests):
    querydict = json.loads(requests.body)
    token = querydict["token"]
    user = models.Profile.objects.get(token=token)
    return HttpResponse(json.dumps({"username": user.username, "role": user.role, "skill": user.skills, "education": user.education, "experience": user.experience}))


def saveprofile(requests):
    querydict = json.loads(requests.body)
    token = querydict["token"]
    prof = models.Profile.objects.get(token=token)
    prof.skills = querydict["skills"]
    prof.experience = querydict["experience"]
    prof.education = querydict["education"]
    prof.role = querydict["role"]
    prof.save()
    return HttpResponse(json.dumps({"status": "saved"}))
