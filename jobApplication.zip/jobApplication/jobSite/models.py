from django.db import models

# Create your models here.


class Job(models.Model):
    post = models.CharField(max_length=100)
    recruiter = models.CharField(max_length=100)
    description = models.TextField()
    salary = models.IntegerField()
    location = models.CharField(max_length=200, default="")
    tags = models.TextField(max_length = 200, default="")
    applications = models.TextField(default="0,0")

class Profile(models.Model):
    token = models.CharField(max_length=20, default=" ")
    experience = models.IntegerField(default=0)
    education = models.CharField(max_length=200, default="  ")
    skills = models.TextField(max_length=100, default="  ")
    role = models.CharField(max_length=100, default="  ")
    username = models.CharField(max_length=50, default="  ")
    